﻿using System;
using System.Linq;

namespace ShoppingSpree
{
    class ShoppingSpree
    {
        static void Main(string[] args)
        {
            string[] people = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries);
            Person[] allPeople = new Person[people.Length];

            for (int i = 0; i < people.Length; i++)
            {
                string[] tokens = people[i].Split("=", StringSplitOptions.RemoveEmptyEntries);

                try
                {
                    Person current = new Person(tokens[0], int.Parse(tokens[1]));
                    allPeople[i] = current;
                }
                catch (ArgumentNullException e)
                {
                    Console.WriteLine("Name cannot be empty");
                    return;
                }
                catch (ArgumentOutOfRangeException e)
                {
                    Console.WriteLine("Money cannot be negative");
                    return;
                }
            }

            string[] products = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries);
            Product[] allProducts = new Product[products.Length];

            for (int i = 0; i < products.Length; i++)
            {
                string[] tokens = products[i].Split("=", StringSplitOptions.RemoveEmptyEntries);

                try
                {
                    Product current = new Product(tokens[0], int.Parse(tokens[1]));
                    allProducts[i] = current;
                }
                catch (ArgumentNullException e)
                {
                    Console.WriteLine("Name cannot be empty");
                    return;
                }
                catch (ArgumentOutOfRangeException e)
                {
                    Console.WriteLine("Money cannot be negative");
                    return;
                }
            }

            string command = Console.ReadLine();

            while (command?.ToUpper() != "END")
            {
                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string buyer = tokens[0];
                string product = tokens[1];

                if (allPeople.Any(a => a.Name == buyer) && allProducts.Any(a => a.Name == product))
                {
                    Person current = allPeople.FirstOrDefault(a => a.Name == buyer);
                    Product item = allProducts.FirstOrDefault(b => b.Name == product);

                    if (current.Money >= item.Cost)
                    {
                        current.BuyProduct(item);
                        Console.WriteLine($"{current.Name} bought {item.Name}");
                    }
                    else
                    {
                        Console.WriteLine($"{current.Name} can't afford {item.Name}");
                    }
                }

                command = Console.ReadLine();
            }

            foreach (var person in allPeople)
            {
                Console.WriteLine($"{person.Name} - {person.ToString()}");
            }
        }
    }
}
