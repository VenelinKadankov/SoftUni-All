﻿using System;
using System.Collections.Generic;

namespace PizzaCaloriesCorrect
{
    public class PizzaCaloriesCorrect
    {
        static void Main(string[] args)
        {
            string[] nameData = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] doughData = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            List<Topping> allToppings = new List<Topping>();

            try
            {
                Dough dough = new Dough(doughData[1], doughData[2], int.Parse(doughData[3]));
                Pizza pizza = new Pizza(nameData[1]); //, dough, allToppings);
                pizza.Dough = dough;

                string commad = Console.ReadLine();

                while (commad?.ToUpper() != "END")
                {
                    string[] toppingData = commad.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                    try
                    {
                        Topping topping = new Topping(toppingData[1], int.Parse(toppingData[2]));

                        try
                        {
                            pizza.AddTopping(topping);
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                            return;
                        }
                        //allToppings.Add(topping);
                    }
                    catch (ArgumentException e)
                    {
                        Console.WriteLine(e.Message);
                        return;
                    }

                    commad = Console.ReadLine();
                }

                //try
                //{
                //    //Pizza pizza = new Pizza(nameData[1], dough, allToppings);
                    Console.WriteLine($"{pizza.Name} - {pizza.Calories:F2} Calories.");
                //}
                //catch (ArgumentException e)
                //{
                //    Console.WriteLine(e.Message);
                //    return;
                //}
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}
