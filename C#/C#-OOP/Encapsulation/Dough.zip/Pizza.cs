﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PizzaCaloriesCorrect
{
    public class Pizza
    {
        private const int minSymbols = 1;
        private const int maxSymbols = 15;

        private string name;
        private Dough dough;
        private readonly List<Topping> toppings;

        public Pizza(string name) //Dough dough, List<Topping> toppings)
        {
            this.Name = name;
            //this.Dough = dough;
            this.toppings = new List<Topping>();
        }

        public Dough Dough
        {
            get 
            { 
                return dough; 
            }
            set 
            {
                dough = value; 
            }
        }

        //public List<Topping> Toppings
        //{
        //    get
        //    {
        //        return this.toppings;
        //    }

        //    private set
        //    {
        //        if (value.Count > 10)
        //        {
        //            throw new ArgumentException("Number of toppings should be in range [0..10].");
        //        }

        //        this.toppings = value;
        //    }
        //}
        public string Name
        {
            get 
            { 
                return name; 
            }
            private set 
            {
                if (string.IsNullOrWhiteSpace(value) || value.Length < minSymbols || value.Length > maxSymbols)
                {
                    throw new ArgumentException($"Pizza name should be between {minSymbols} and {maxSymbols} symbols");
                }

                name = value; 
            }
        }

        public double Calories
        {
            get
            {
                double calories = Dough.Calories;

                foreach (var top in toppings)
                {
                    calories += top.Calories;
                }

                return calories;
            }
        }

        public void AddTopping(Topping topping)
        {
            if (toppings.Count > 10)
            {
                throw new ArgumentException("Number of toppings should be in range [0..10].");
            }

            toppings.Add(topping);
        }

    }
}
