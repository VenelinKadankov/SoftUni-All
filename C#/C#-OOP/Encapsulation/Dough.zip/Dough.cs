﻿using System;
using System.Collections.Generic;

namespace PizzaCaloriesCorrect
{
    public class Dough
    {
        private const int minWeight = 1;
        private const int maxWeight = 200;
        private const double baseCalories = 2;

        private readonly Dictionary<string, double> flourType = new Dictionary<string, double>
        {
            { "white", 1.5 },
            { "wholegrain", 1.0 }
        };
        private readonly Dictionary<string, double> bakingTechnique = new Dictionary<string, double>
        {
            { "crispy", 0.9 },
            { "chewy", 1.1 },
            { "homemade", 1.0 }
        };

        private int weight;
        private string type;
        private string technique;

        public Dough(string type, string technique, int weight)
        {
            this.Type = type;
            this.Technique = technique;
            this.Weight = weight;
        }

        public int Weight
        {
            get 
            { 
                return this.weight; 
            }
            private set 
            {
                if (value < minWeight || value > maxWeight)
                {
                    throw new ArgumentException($"Dough weight should be in the range [{minWeight}..{maxWeight}].");
                }
                weight = value; 
            }
        }

        public string Type
        {
            get 
            { 
                return this.type; 
            }
            private set 
            {
                if (!flourType.ContainsKey(value?.ToLower()))
                {
                    throw new ArgumentException("Invalid type of dough.");
                }

                this.type = value; 
            }
        }

        public string Technique
        {
            get 
            { 
                return this.technique; 
            }
            private set 
            {
                if (!bakingTechnique.ContainsKey(value?.ToLower()))
                {
                    throw new ArgumentException("Invalid type of dough.");
                }

                this.technique = value; 
            }
        }

        public double Calories 
        { 
            get 
            {
                return weight * baseCalories * flourType[type.ToLower()] * bakingTechnique[technique.ToLower()];
            } 
        }
    }
}
