﻿using System;
using System.Collections.Generic;

namespace PizzaCaloriesCorrect
{
    public class Topping
    {
        private const int minWeight = 1;
        private const int maxWeight = 50;
        private const double caloriesPerGram = 2;

        private readonly Dictionary<string, double> toppingTypes = new Dictionary<string, double>
        {
            { "meat", 1.2},
            { "veggies", 0.8},
            { "cheese", 1.1},
            { "sauce", 0.9}
        };

        public Topping(string name, int grams)
        {
            this.Type = name;
            this.Weight = grams;
        }

        private int weight;
        private string type;

        public string Type
        {
            get 
            { 
                return this.type; 
            }
            private set 
            {
                if (!toppingTypes.ContainsKey(value?.ToLower()))
                {
                    throw new ArgumentException($"Cannot place {value} on top of your pizza.");
                }

                this.type = value; 
            }
        }
        public int Weight
        {
            get 
            { 
                return this.weight;
            }
            private set 
            {
                if (value < minWeight || value > maxWeight)
                {
                    throw new ArgumentException($"{Type} weight should be in the range [{minWeight}..{maxWeight}].");
                }

                this.weight = value; 
            }
        }

        public double Calories
        {
            get
            {
                return this.weight * caloriesPerGram * toppingTypes[type.ToLower()];
            }
        }
    }
}
