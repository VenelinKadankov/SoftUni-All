﻿using System;

namespace ClassBoxData
{
    public class ClassBoxData
    {
        static void Main(string[] args)
        {
            double length = double.Parse(Console.ReadLine());
            double width = double.Parse(Console.ReadLine());
            double height = double.Parse(Console.ReadLine());

            try
            {
                Box box = new Box(length, width, height);
                Console.WriteLine($"Surface Area - {box.CalcSurfaceArea():F2}");
                Console.WriteLine($"Lateral Surface Area - {box.CalcLateralSurfaceArea():F2}");
                Console.WriteLine($"Volume - {box.CalcVolume():F2}");
            }
            catch(ArgumentException)
            {
                if (length <= 0)
                {
                    Console.WriteLine("Length cannot be zero or negative.");
                }
                else if (width <= 0)
                {
                    Console.WriteLine("Width cannot be zero or negative.");
                }
                else
                {
                    Console.WriteLine("Height cannot be zero or negative.");
                }

            }


        }
    }
}
