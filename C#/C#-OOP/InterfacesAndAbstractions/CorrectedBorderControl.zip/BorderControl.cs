﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<string> detained = new List<string>();
            var test = new List<IIdable>();

            string command = Console.ReadLine();

            while (command?.ToUpper() != "END")
            {
                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (tokens[0]?.ToUpper() == "ROBOT")
                {
                    detained.Add(tokens[1]);
                    IIdable robot = new Robot(tokens[0], tokens[1]);
                    test.Add(robot);

                }
                else if (tokens[0]?.ToUpper() == "CITIZEN")
                {
                    IIdable citizen = new Citizen(tokens[0], tokens[1], tokens[2]);
                    //test.Add(citizen);
                    detained.Add(tokens[2]);
                }
                else
                {
                    IIdable pet = new Robot(tokens[0], tokens[1]);
                    detained.Add(tokens[1]);
                    test.Add(pet);
                }

                command = Console.ReadLine();
            }

            string year = Console.ReadLine();

            //foreach (var item in test)
            //{
            //    if (!item.ValidityCheck(year))
            //    {
            //        Console.WriteLine(item.Birthday);
            //    }
            //}

            foreach (var item in detained)
            {
                if (item.EndsWith(year))
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}
