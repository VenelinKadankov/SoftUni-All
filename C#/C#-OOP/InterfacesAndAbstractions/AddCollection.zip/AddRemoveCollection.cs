﻿using System.Collections.Generic;

namespace CollectionHierarchy
{
    public class AddRemoveCollection : ICustomList
    {
        public AddRemoveCollection()
        {
            this.Items = new List<string>(100);
        }

        public List<string> Items { get; private set; }

        public string Remove()
        {
            string item = Items[^1];
            this.Items.RemoveAt(Items.Count - 1);

            return item;
        }

        public int Add(string item)
        {
            this.Items.Insert(0, item);

            return 0;
        }
    }
}
