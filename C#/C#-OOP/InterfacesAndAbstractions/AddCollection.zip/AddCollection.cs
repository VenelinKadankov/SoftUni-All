﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectionHierarchy
{
    public class AddCollection : ICustomList
    {
        public AddCollection()
        {
            this.Items = new List<string>(100);
        }

        public List<string> Items { get; private set; }
        public int Add(string item)
        {
            this.Items.Add(item);

            return Items.IndexOf(item);
        }

    }
}
