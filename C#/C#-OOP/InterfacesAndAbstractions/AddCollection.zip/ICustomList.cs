﻿namespace CollectionHierarchy
{
    public interface ICustomList
    {
        public int Add(string item);

       //public string Remove();
    }
}
