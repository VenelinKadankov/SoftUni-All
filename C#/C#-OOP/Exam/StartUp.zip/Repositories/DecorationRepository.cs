﻿using AquaShop.Models.Decorations.Contracts;
using AquaShop.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AquaShop.Repositories
{
    public class DecorationRepository : IRepository<IDecoration>
    {
        private readonly ICollection<IDecoration> models = new List<IDecoration>();


        public IReadOnlyCollection<IDecoration> Models
        {
            get
            {
                return (IReadOnlyCollection<IDecoration>)this.models;//.AsReadOnly();
            }
          
        }

        public void Add(IDecoration model)
        {
            this.models.Add(model);
        }

        public IDecoration FindByType(string type)
        {
            var result = models.FirstOrDefault(x => x.GetType().Name == type);

            return result;
        } 

        public bool Remove(IDecoration model)
        {
            return models.Remove(model);
        }
    }
}
