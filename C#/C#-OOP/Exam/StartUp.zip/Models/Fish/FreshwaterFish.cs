﻿using AquaShop.Models.Aquariums.Contracts;
using AquaShop.Models.Fish.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Models.Fish
{
    public class FreshwaterFish : Fish
    {
        public FreshwaterFish(string name, string species, decimal price) 
            : base(name, species, price)
        {
            this.Size = 3;
        }

        public override void Eat()
        {
            this.Size += 3;
        }

        //public override bool CanLive(string aquarium)
        //{
        //    if (aquarium == "FreshwaterAquarium")
        //    {
        //        return true;
        //    }

        //    return false;
        //}

    }
}
