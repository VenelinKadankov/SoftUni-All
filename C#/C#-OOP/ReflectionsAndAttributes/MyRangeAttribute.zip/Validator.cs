﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace ValidationAttributes
{
    public static class Validator
    {
        public static bool IsValid(object obj)
        {
            Type type = obj.GetType();
            PropertyInfo[] propInfos = type.GetProperties();

            foreach (PropertyInfo propInfo in propInfos)
            {
                List<MyValidationAttribute> myValidationAttributes = propInfo.GetCustomAttributes<MyValidationAttribute>().ToList();
                object propertyObj = propInfo.GetValue(obj);

                foreach (MyValidationAttribute attribute in myValidationAttributes)
                {
                    bool isValid = attribute.IsValid(propertyObj);

                    if (!isValid)
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}
