﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace ValidationAttributes
{
    public class MyRequiredAttribute : MyValidationAttribute
    {

        public override bool IsValid(object obj)
        {
            //Type currentType = obj.GetType();

            //FieldInfo[] tempObj = currentType.GetFields(BindingFlags.Public |
            //    BindingFlags.Instance |
            //    BindingFlags.Static |
            //    BindingFlags.NonPublic);

            //foreach (FieldInfo fieldInfo in tempObj)
            //{
            //    if (fieldInfo.CustomAttributes.Any(a => a.AttributeType == typeof(MyRangeAttribute)))
            //    {
            //        return true;
            //    }
            //}

            return obj != null ? true : false;

            //if (obj != null)
            //{
            //    return true;
            //}
            //;
            //return false;
        }
    }
}
