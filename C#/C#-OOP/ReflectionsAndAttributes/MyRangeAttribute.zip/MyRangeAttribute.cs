﻿using System;
using System.Linq;
using System.Reflection;

namespace ValidationAttributes
{
    public class MyRangeAttribute : MyValidationAttribute
    {
        private int minValue;
        private int maxValue;

        public MyRangeAttribute(int minValue, int maxValue)
        {
            this.minValue = minValue;
            this.maxValue = maxValue;
        }

        public override bool IsValid(object obj)
        {
            //Type currentType = obj.GetType();

            //FieldInfo[] tempObj = currentType.GetFields(BindingFlags.Public |
            //    BindingFlags.Instance |
            //    BindingFlags.Static |
            //    BindingFlags.NonPublic);

            //foreach (FieldInfo fieldInfo in tempObj)
            //{
            //    if (fieldInfo.CustomAttributes.Any(a => a.AttributeType == typeof(MyRangeAttribute)))
            //    {
            //        int age = (int)fieldInfo.GetValue(obj);

            //        if (minValue <= age && age <= maxValue)
            //        {
            //            return true;
            //        }
            //    }
            //}

            int intObj = Convert.ToInt32(obj);

            return this.minValue <= intObj && intObj <= this.maxValue;

            ;
        }
    }
}
