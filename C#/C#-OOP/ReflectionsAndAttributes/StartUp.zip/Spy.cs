﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {

        public string StealFieldInfo(string nameClass, params string[] fieldNames)
        {
            StringBuilder sb = new StringBuilder();

            var spiedClass = Type.GetType(nameClass);

            ;
            Hacker classInstance = (Hacker)Activator.CreateInstance(spiedClass);
            sb.AppendLine($"Class under investigation: {spiedClass.FullName}");
            ;
            foreach (var fieldName in fieldNames)
            {
                FieldInfo fieldInfo = spiedClass.GetField(fieldName, BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public);
                sb.AppendLine($"{fieldInfo.Name} = {fieldInfo.GetValue(classInstance)}");
            }


            return sb.ToString();
        }

        public string AnalyzeAcessModifiers(string className)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                Type hackerInfo = Type.GetType(className);

                FieldInfo[] fieldsInfo = hackerInfo.GetFields(
                    BindingFlags.Public |
                    BindingFlags.Instance |
                    BindingFlags.Static);

                MethodInfo[] publicFieldsInfo = hackerInfo.GetMethods(
                    BindingFlags.Public |
                    BindingFlags.Instance);

                MethodInfo[] privateFieldsInfo = hackerInfo.GetMethods(
                    BindingFlags.NonPublic |
                    BindingFlags.Instance);

                foreach (var field in fieldsInfo)
                {
                    sb.AppendLine($"{field.Name} must be private!");
                }

                foreach (var method in privateFieldsInfo.Where(modifier => modifier.Name.StartsWith("get")))
                {
                    sb.AppendLine($"{method.Name} have to be public!");
                }

                foreach (var method in publicFieldsInfo.Where(mod => mod.Name.StartsWith("set")))
                {
                    sb.AppendLine($"{method.Name} have to be private!");
                }

            }
            catch (Exception e)
            {
                throw new ArgumentNullException("Invalid value!", e);
                throw;
            }



            return sb.ToString();
        }

        public string RevealPrivateMethods(string className)
        {
            StringBuilder sb = new StringBuilder();
            Type hackerType = Type.GetType(className);

            sb.AppendLine($"All Private Methods of Class: {hackerType.FullName}");
            sb.AppendLine($"Base Class: {hackerType.BaseType.Name}");

            MethodInfo[] methodInfos = hackerType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Static);

            foreach (var method in methodInfos)
            {
                sb.AppendLine(method.Name);
            }


            return sb.ToString();
        }

        public string CollectGettersAndSetters(string className)
        {
            StringBuilder sb = new StringBuilder();

            Type classType = Type.GetType(className);

            MethodInfo[] methodInfos = classType.GetMethods(BindingFlags.Public | 
                BindingFlags.Instance |
                BindingFlags.Static | 
                BindingFlags.NonPublic);

            //FieldInfo[] fieldInfos = classType.GetFields(BindingFlags.Static |
            //    BindingFlags.Instance | 
            //    BindingFlags.Public | 
            //    BindingFlags.NonPublic);
            Queue<Type> queue = new Queue<Type>();

            foreach (var method in methodInfos.Where(m => m.Name.StartsWith("get")))
            {
                sb.AppendLine($"{method.Name} will return {method.ReturnType}");
                queue.Enqueue(method.ReturnType);
            }

            foreach (var method in methodInfos.Where(m => m.Name.StartsWith("set")))
            {
                sb.AppendLine($"{method.Name} will set field of {queue.Dequeue()}");
            }

            return sb.ToString();
        }
    }
}
