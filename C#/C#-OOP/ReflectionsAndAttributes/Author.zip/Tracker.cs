﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace AuthorProblem
{
    public class Tracker
    {

        public void PrintMethodsByAuthor()
        {
            Type classType = typeof(StartUp);
            MethodInfo[] methodInfos = classType.GetMethods(BindingFlags.Public |
                BindingFlags.Instance |
                BindingFlags.Static |
                BindingFlags.NonPublic);

            foreach (var infoCurrent in methodInfos)
            {
                if (infoCurrent.CustomAttributes.Any(a => a.AttributeType == typeof(AuthorAttribute)))
                {
                    var atts = infoCurrent.GetCustomAttributes(false);

                    foreach (AuthorAttribute att in atts)
                    {
                        Console.WriteLine($"{infoCurrent.Name} is written by {att.Name}");
                    }
                }
            }
        }
    }
}
