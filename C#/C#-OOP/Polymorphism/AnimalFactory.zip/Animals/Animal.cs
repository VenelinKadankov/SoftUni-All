﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Animals
{
    public abstract class Animal
    {

        public Animal(string name, double weight)
        {
            this.Name = name;
            this.Weight = weight;
            this.FoodEaten = 0;
        }

        public string Name { get; protected set; }

        public double Weight { get; protected set; }

        public int FoodEaten { get; set; }

        public abstract string ProduceSound();

        public virtual void Eat(string food, int quantity)
        {
            Weight += 0.35 * quantity;
            FoodEaten += quantity;
        }
    }
}
