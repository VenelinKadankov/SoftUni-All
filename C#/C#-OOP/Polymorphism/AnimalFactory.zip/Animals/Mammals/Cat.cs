﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WildFarm.Animals.Mammals
{
    public class Cat : Feline
    {
        private readonly string[] foods = new string[] { "vegetable", "meat" };

        public Cat(string name, double weight, string region, string breed) 
            : base(name, weight, region, breed)
        {
        }

        public override void Eat(string food, int quantity)
        {
            if (!foods.Contains(food?.ToLower()))
            {
                throw new ArgumentException($"{this.GetType().Name} does not eat {food}!");
            }

            Weight += 0.3 * quantity;
            FoodEaten += quantity;

        }

        public override string ProduceSound()
        {
            return "Meow";
        }
    }
}
