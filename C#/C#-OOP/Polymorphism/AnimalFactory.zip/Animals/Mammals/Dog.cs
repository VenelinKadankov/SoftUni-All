﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WildFarm.Animals.Mammals
{
    public class Dog : Mammal
    {
        private readonly string[] foods = new string[] { "meat" };

        public Dog(string name, double weight, string region)
            : base (name, weight, region)
        {

        }

        public override void Eat(string food, int quantity)
        {
            if (!foods.Contains(food?.ToLower()))
            {
                throw new ArgumentException($"{this.GetType().Name} does not eat {food}!");
            }

            Weight += 0.4 * quantity;
            FoodEaten += quantity;
        }

        public override string ProduceSound()
        {
            return "Woof!";
        }
    }
}
