﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WildFarm.Animals.Mammals
{
    public class Tiger : Feline
    {
        private readonly string[] foods = new string[] { "meat" };

        public Tiger(string name, double weight, string region, string breed) 
            : base(name, weight, region, breed)
        {
        }

        public override void Eat(string food, int quantity)
        {
            if (!foods.Contains(food?.ToLower()))
            {
                throw new ArgumentException($"{this.GetType().Name} does not eat {food}!");
            }

            Weight += 1.0 * quantity;
            FoodEaten += quantity;
        }

        public override string ProduceSound()
        {
            return "ROAR!!!";
        }
    }
}
