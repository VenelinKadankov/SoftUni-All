﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WildFarm.Animals.Birds
{
    public class Owl : Bird
    {
        private readonly string[] foods = new string[] { "meat" };

        public Owl(string name, double weight, double wingSize)
            : base(name, weight, wingSize)
        {

        }

        public override void Eat(string food, int quantity)
        {
            if (!foods.Contains(food?.ToLower()))
            {
                throw new ArgumentException($"{this.GetType().Name} does not eat {food}!");
            }

            Weight += 0.25 * quantity;
            FoodEaten += quantity;
        }

        public override string ProduceSound()
        {
            return "Hoot Hoot"; ;
        }
    }
}
