﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.AnimalFactory;
using WildFarm.Animals;

namespace WildFarm.Core
{
    public class Engine
    {
        private AnimalCreator animalCreator;

        public Engine()
        {
            this.animalCreator = new AnimalCreator();
        }

        public void Run()
        {
            List<Animal> animals = CreateAnimals();

            foreach (var item in animals)
            {
                Console.WriteLine(item.ToString());
            }
        }

        private List<Animal> CreateAnimals()
        {
            List<Animal> animals = new List<Animal>();
            string command = Console.ReadLine();

            while (command?.ToUpper() != "END")
            {
                string[] animalInfo = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string[] foodInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                try
                {
                    Animal animal = animalCreator.CreateAnimal(animalInfo);
                    Console.WriteLine(animal.ProduceSound());

                    try
                    {
                        animal.Eat(foodInfo[0], int.Parse(foodInfo[1]));
                    }
                    catch (ArgumentException e)
                    {
                        Console.WriteLine(e.Message);
                    }

                    animals.Add(animal);
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }



                command = Console.ReadLine();
            }

            return animals;
        }
    }
}
