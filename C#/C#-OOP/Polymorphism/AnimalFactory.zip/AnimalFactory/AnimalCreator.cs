﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Animals;
using WildFarm.Animals.Birds;
using WildFarm.Animals.Mammals;

namespace WildFarm.AnimalFactory
{
    public class AnimalCreator
    {

        public Animal CreateAnimal(string[] tokens)
        {
            Animal animal;

            if (tokens[0] == "Cat")
            {
                animal = new Cat(tokens[1], double.Parse(tokens[2]), tokens[3], tokens[4]);
            }
            else if (tokens[0] == "Mouse")
            {
                animal = new Mouse(tokens[1], double.Parse(tokens[2]), tokens[3]);
            }
            else if (tokens[0] == "Tiger")
            {
                animal = new Tiger(tokens[1], double.Parse(tokens[2]), tokens[3], tokens[4]);
            }
            else if (tokens[0] == "Dog")
            {
                animal = new Dog(tokens[1], double.Parse(tokens[2]), tokens[3]);
            }
            else if (tokens[0] == "Hen")
            {
                animal = new Hen(tokens[1], double.Parse(tokens[2]), double.Parse(tokens[3]));
            }
            else if (tokens[0] == "Owl")
            {
                animal = new Owl(tokens[1], double.Parse(tokens[2]), double.Parse(tokens[3]));
            }
            else
            {
                throw new ArgumentException("No such animal");
            }

            return animal;
        }
    }
}
