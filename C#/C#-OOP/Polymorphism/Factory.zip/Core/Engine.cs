﻿using System;
using System.Collections.Generic;
using Raiding.Factory;

namespace Raiding.Core
{
    public class Engine
    {
        private HeroFactory heroFactory;

        public Engine()
        {
            this.heroFactory = new HeroFactory();
        }

        public void Run()
        {
            List<BaseHero> group = new List<BaseHero>();

            int count = int.Parse(Console.ReadLine());

            while(group.Count < count)
            {
                try
                {
                    BaseHero hero = CreateHero();
                    group.Add(hero);
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            int bossPower = int.Parse(Console.ReadLine());
            int totalPower = 0;

            foreach (var item in group)
            {
                totalPower += item.Power;
                Console.WriteLine(item.CastAbility());
            }

            if (totalPower >= bossPower)
            {
                Console.WriteLine("Victory!");
            }
            else
            {
                Console.WriteLine("Defeat...");
            }
        }

        private BaseHero CreateHero()
        {
            string name = Console.ReadLine();
            string type = Console.ReadLine();
            BaseHero hero = this.heroFactory.CreateHero(type, name);

            return hero;
        }
    }
}
