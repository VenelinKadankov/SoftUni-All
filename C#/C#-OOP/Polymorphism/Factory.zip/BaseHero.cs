﻿namespace Raiding
{
    public abstract class BaseHero
    {

        public BaseHero(string name)
        {
            this.Name = name;

        }
        public abstract string Name { get; protected set; }

        public abstract int Power { get; protected set; }

        public abstract string CastAbility();
    }
}
