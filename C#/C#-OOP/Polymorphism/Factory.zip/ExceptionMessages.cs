﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public class ExceptionMessages
    {
        public static string InvalidTypeOfHero =
            "Invalid hero!";
    }
}
