﻿namespace Raiding
{
    public class Warrior : BaseHero
    {
        private const int power = 100;
        //private string name;
        public Warrior(string name)
            : base(name)
        {
            this.Name = name;
            this.Power = power;
        }

        public override string Name { get; protected set; }
        public override int Power { get; protected set; }

        public override string CastAbility()
        {
            return $"{this.GetType().Name} - {Name} hit for {Power} damage";
        }
    }
}
