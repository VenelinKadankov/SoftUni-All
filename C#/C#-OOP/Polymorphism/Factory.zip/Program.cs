﻿using Raiding.Core;

namespace Raiding
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();

        }
    }
}
