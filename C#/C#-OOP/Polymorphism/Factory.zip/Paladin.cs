﻿namespace Raiding
{
    public class Paladin : BaseHero
    {
        private const int power = 100;
        public Paladin(string name)
            : base(name)
        {
            this.Name = name;
            this.Power = power;
        }

        public override string Name { get; protected set; }
        public override int Power { get; protected set; }

        public override string CastAbility()
        {
            return $"{this.GetType().Name} - {Name} healed for {Power}";
        }
    }
}
