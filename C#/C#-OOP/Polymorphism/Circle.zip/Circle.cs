﻿using System;

namespace Shapes
{
    public class Circle : Shape
    {
        //private readonly double radius;

        private double radius;

        public double Radius
        {
            get 
            {
                return radius; 
            }

            private set 
            {
                if (value <= 0)
                {
                    throw new ArgumentException();
                }

                radius = value; 
            }
        }


        public Circle(double radius)
        {
            this.Radius = radius;
        }

        public override double CalculateArea()
        {
            return Math.PI * Radius * Radius;
        }

        public override double CalculatePerimeter()
        {
            return Math.PI * 2 * Radius;
        }

        public override string Draw()
        {
            return base.Draw() + "Circle";
        }
    }
}
