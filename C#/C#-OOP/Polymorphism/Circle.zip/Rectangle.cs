﻿using System;

namespace Shapes
{
    public class Rectangle : Shape
    {
        //private readonly double height;

        //private readonly double width;

        private double height;

        public double Height
        {
            get 
            { 
                return height; 
            }

            private set 
            {
                if (value <= 0)
                {
                    throw new ArgumentException();
                }

                this.height = value;
            }
        }

        private double width;

        public double Width
        {
            get 
            { 
                return width; 
            }

            private set 
            {
                if (value <= 0)
                {
                    throw new ArgumentException();
                }

                width = value; 
            }
        }



        public Rectangle(double height, double width)
        {
            this.Height = height;
            this.Width = width;
        }



        public override double CalculateArea()
        {
            return Height * Width;
        }

        public override double CalculatePerimeter()
        {
            return 2 * (Height + Width);
        }

        public override string Draw()
        {
            return base.Draw() + "Rectangle";
        }
    }
}
