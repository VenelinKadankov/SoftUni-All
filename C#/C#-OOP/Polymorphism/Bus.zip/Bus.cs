﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Bus : Vehicle
    {
        private const double acIncrease = 1.4;

        public Bus(double fuel, double consumption, double capacity) 
            : base(fuel, consumption, capacity)
        {
        }

        protected override double FuelConsumption { get; set; }

        public string Drive(bool isEmpty, double km)
        {
            if (isEmpty)
            {
                if (km * FuelConsumption <= FuelQuantity)
                {
                    FuelQuantity -= km * FuelConsumption;

                    return $"{this.GetType().Name} travelled {km} km";
                }
                else
                {
                    return $"{this.GetType().Name} needs refueling";
                }
            }
            else
            {
                if (km * (FuelConsumption + acIncrease) <= FuelQuantity)
                {
                    FuelQuantity -= km * (FuelConsumption + acIncrease);

                    return $"{this.GetType().Name} travelled {km} km";
                }
                else
                {
                    return $"{this.GetType().Name} needs refueling";
                }
            }

        }
    }
}
