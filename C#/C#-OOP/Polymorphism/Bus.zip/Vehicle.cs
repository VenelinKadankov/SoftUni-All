﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        private double fuelQuantity;
        public Vehicle(double fuel, double consumption, double capacity)
        {
            this.TankCapacity = capacity;
            this.FuelQuantity = fuel;
            this.FuelConsumption = consumption;
        }

        public double TankCapacity { get; set; }
        public virtual double FuelQuantity 
        {
            get => fuelQuantity;
            set
            {
                if (value > TankCapacity)
                {
                    value = 0;
                }

                fuelQuantity = value;
            }
        }

        protected abstract double FuelConsumption { get; set; }

        public double Distance { get; protected set; }

        public virtual string Drive(double km)
        {
            if (km * FuelConsumption <= FuelQuantity)
            {
                FuelQuantity -= km * FuelConsumption;

                return $"{this.GetType().Name} travelled {km} km";
            }
            else
            {
                return $"{this.GetType().Name} needs refueling";
            }
        }

        public virtual void Refuel(double lt)
        {
            if (fuelQuantity + lt > TankCapacity)
            {
                throw new ArgumentException($"Cannot fit {lt} fuel in the tank");
            }

            if (lt <= 0)
            {
                throw new ArgumentException("Fuel must be a positive number");
            }

            FuelQuantity += lt;
        }
    }

}

