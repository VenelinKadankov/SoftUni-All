﻿using System;
using System.Linq;

namespace Vehicles
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            string[] truckInfo = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            string[] busInfo = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            Vehicle car = new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]), double.Parse(carInfo[3]));
            Vehicle truck = new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]), double.Parse(truckInfo[3]));
            Vehicle bus = new Bus(double.Parse(busInfo[1]), double.Parse(busInfo[2]), double.Parse(busInfo[3]));

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (tokens[0] == "Drive")
                {
                    if (tokens[1] == "Car")
                    {
                        Console.WriteLine(car.Drive(double.Parse(tokens[2])));
                    }
                    else if (tokens[1] == "Truck")
                    {
                        Console.WriteLine(truck.Drive(double.Parse(tokens[2])));
                    }
                    else
                    {
                        Console.WriteLine((bus as Bus).Drive(false, double.Parse(tokens[2])));
                    }
                }
                else if (tokens[0] == "DriveEmpty")
                {
                    Console.WriteLine((bus as Bus).Drive(true, double.Parse(tokens[2])));
                }
                else
                {
                    try
                    {
                        if (tokens[1] == "Car")
                        {
                            car.Refuel(double.Parse(tokens[2]));
                        }
                        else if (tokens[1] == "Truck")
                        {
                            truck.Refuel(double.Parse(tokens[2]));
                        }
                        else
                        {
                            bus.Refuel(double.Parse(tokens[2]));
                        }
                    }
                    catch (ArgumentException e)
                    {
                        Console.WriteLine(e.Message);
                    }

                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:F2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
            Console.WriteLine($"Bus: {bus.FuelQuantity:F2}");
        }
    }
}
