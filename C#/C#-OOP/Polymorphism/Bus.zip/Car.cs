﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : Vehicle
    {
        private const double acIncreacse = 0.9;
        //private double fuelQuantity;
        private double fuelConsumption;

        public Car(double fuel, double consumption, double capacity)
            : base(fuel, consumption, capacity)
        {
        }


        //public override double FuelQuantity 
        //{
        //    get => this.fuelQuantity;
        //    set
        //    {
        //        this.fuelQuantity = value;
        //    } 
        //}
        protected override double FuelConsumption 
        {
            get => fuelConsumption + acIncreacse;

            set
            {
                this.fuelConsumption = value;
            } 
        }

    }
}
