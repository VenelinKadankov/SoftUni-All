﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        private const double acIncrease = 1.6;
        private const double holeDecrease = 0.95;
        //private double fuelQuantity;
        private double fuelConsumption;

        public Truck(double fuel, double consumption, double capacity)
            : base(fuel, consumption, capacity)
        {
        }

        //public override double FuelQuantity 
        //{ 
        //    get => fuelQuantity;
        //    set 
        //    {
        //        this.fuelQuantity = value;
        //    }
        //}


        protected override double FuelConsumption 
        {
            get => fuelConsumption + acIncrease;
            set 
            {
                fuelConsumption = value;
            }
        }

        public override void Refuel(double lt)
        {

            if (FuelQuantity + lt > TankCapacity)
            {
                throw new ArgumentException($"Cannot fit {lt} fuel in the tank");
            }

            if (lt <= 0)
            {
                throw new ArgumentException("Fuel must be a positive number");
            }

            FuelQuantity += lt * holeDecrease; ;
        }
    }
}
