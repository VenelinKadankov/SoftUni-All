//using DatabaseProblem;
using NUnit.Framework;
using System;
using System.Reflection;

namespace Tests
{
    [TestFixture]
    public class DatabaseTests
    {
        private Database database;

        [SetUp]
        public void Setup()
        {
            int[] arr = new int[16];
            database = new Database(arr);
        }

        [Test]
        public void CheckDatabaseCapacityIsCorrect()
        {
            Assert.That(database.Count, Is.EqualTo(16));
        }

        [Test]
        public void AddingToFullDatabaseShouldBeInvalid()
        {
            Assert.That(() => database.Add(2),
                Throws.InvalidOperationException.With.Message.EqualTo("Array's capacity must be exactly 16 integers!"));
        }

        [Test]
        public void CheckIfRemovedValueIsFromEndAndDatabaseIsNotEmpty()
        {
            database = new Database();

            Assert.That(() => database.Remove(),
                Throws.InvalidOperationException.With.Message.EqualTo("The collection is empty!"));
        }

        [Test]
        public void CheckIfParametersGivenToCtorAreInt()
        {
            database = new Database();

            database.Add(2);
            database.Add(3);
            string result = string.Join(" ", database.Fetch());
            string expected = "2 3";

            Assert.AreEqual(result, expected);
        }

        [Test]
        public void CheckArrayAfterRemoveElement()
        {
            database = new Database(2, 3, 4);
            database.Remove();

            string result = string.Join(" ", database.Fetch());
            string expected = "2 3";

            Assert.AreEqual(result, expected);
        }
    }
}