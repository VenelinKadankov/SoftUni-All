﻿//using FightingArena;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Tests
{
    public class ArenaTests
    {
        private Arena arena;

        [SetUp]
        public void Setup()
        {
            arena = new Arena();
        }

        [Test]
        public void CheckConstructorWors()
        {
            Assert.IsNotNull(arena);
        }

        [Test]
        public void CheckWarriorsGetter()
        {
            IReadOnlyCollection<Warrior> warriors = arena.Warriors;

            Assert.IsNotNull(warriors);
        }

        [Test]
        public void CheckCounter()
        {
            arena.Enroll(new Warrior("Pesho", 20, 200));

            Assert.AreEqual(arena.Count, 1);
        }

        [Test]
        public void CheckDoubleEnrolment()
        {
            Warrior testWarior = new Warrior("Pesho", 20, 200);
            arena.Enroll(testWarior);

            Assert.Throws<InvalidOperationException>(() => arena.Enroll(testWarior));
        }

        [Test]
        public void CheckEnrolment()
        {
            int expected = arena.Count + 1;
            Warrior testWarior = new Warrior("Pesho", 20, 200);
            arena.Enroll(testWarior);

            Assert.That(expected, Is.EqualTo(1));
        }

        [Test]
        public void CheckEnrolmentWithSameName()
        {
            int expected = arena.Count + 1;
            Warrior testWarior = new Warrior("Pesho", 20, 200);
            arena.Enroll(testWarior);

            Assert.Throws<InvalidOperationException>(() => arena.Enroll(new Warrior("Pesho", 30, 50)));
        }


        [Test]
        public void TestFightWithNullAttacker()
        {
            Warrior testWarrior = new Warrior("Pesho", 20, 200);
            arena.Enroll(testWarrior);

            Assert.Throws<InvalidOperationException>(() => arena.Fight("Gosho", "Pesho"));
        }

        [Test]
        public void TestFightWithNullDefender()
        {
            Warrior testWarrior = new Warrior("Pesho", 20, 200);
            arena.Enroll(testWarrior);

            Assert.Throws<InvalidOperationException>(() => arena.Fight("Pesho", "Gosho"));
        }

        [Test]
        public void TestFightWithLegitWarriors()
        {
            Warrior firstWarrior = new Warrior("Ceko", 20, 200);
            Warrior secondWarrior = new Warrior("Gosho", 20, 100);
            arena.Enroll(firstWarrior);
            arena.Enroll(secondWarrior);

            arena.Fight("Ceko", "Gosho");

            Assert.That(firstWarrior.HP, Is.EqualTo(180));
            Assert.That(secondWarrior.HP, Is.EqualTo(80));
        }
    }
}
