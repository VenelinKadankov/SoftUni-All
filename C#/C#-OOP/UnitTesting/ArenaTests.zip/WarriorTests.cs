//using FightingArena;
using NUnit.Framework;
using System;

namespace Tests
{
    [TestFixture]
    public class WarriorTests
    {

        private Warrior warrior;

        [SetUp]
        public void Setup()
        {
            warrior = new Warrior("Pesho", 20, 100);
        }

        [Test]
        public void TestConstructorWorksProperly()
        {
            Assert.IsNotNull(warrior);
        }

        [Test]
        public void TestConstructorWorks()
        {
            string expectedName = "Pesho";
            int expectedDmg = 20;
            int expectedHp = 100;

            Assert.AreEqual(expectedName, warrior.Name);
            Assert.AreEqual(expectedDmg, warrior.Damage);
            Assert.AreEqual(expectedHp, warrior.HP);

        }

        [Test]
        public void ConfirmNameIsNotNull()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                warrior = new Warrior(null, 20, 100);
            });
        }

        [Test]
        public void ConfirmNameIsNotEmpty()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                warrior = new Warrior(string.Empty, 20, 100);
            });
        }

        [Test]
        public void ConfirmNameIsNotWhiteSpace()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                warrior = new Warrior("    ", 20, 100);
            });
        }

        [Test]
        public void ConfirmDamageIsNotZero()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                warrior = new Warrior("Pesho", 0, 100);
            });
        }

        [Test]
        public void ConfirmDamageIsNotNegative()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                warrior = new Warrior("Pesho", -20, 100);
            });
        }

        [Test]
        public void ConfirmHealthIsNotNegative()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                warrior = new Warrior("Pesho", 20, -100);
            });
        }

        [Test]
        public void CheckAttackWithLessThanMinimumPoints()
        {
            warrior = new Warrior("Pesho", 10, 30);
            Warrior attackedWarrior = new Warrior("Gosho", 20, 50);

            Assert.Throws<InvalidOperationException>(() => warrior.Attack(attackedWarrior));
        }

        [Test]
        public void CheckAttackSomebodyWithMinimumPoints()
        {
            warrior = new Warrior("Pesho", 10, 200);
            Warrior attackedWarrior = new Warrior("Gosho", 50, 30);

            Assert.Throws<InvalidOperationException>(() => warrior.Attack(attackedWarrior));
        }

        [Test]
        public void AttackSomebodyWithMoreDamageThanCurrentHP()
        {
            warrior = new Warrior("Pesho", 10, 40);
            Warrior attackedWarrior = new Warrior("Gosho", 50, 40);

            Assert.Throws<InvalidOperationException>(() => warrior.Attack(attackedWarrior));
        }

        [Test]
        public void CheckAfterAttackHerroAndEnemyLooseHp()
        {
            warrior = new Warrior("Pesho", 100, 400);
            Warrior attackedWarrior = new Warrior("Gosho", 20, 200);

            warrior.Attack(attackedWarrior);

            Assert.That(warrior.HP, Is.EqualTo(380));
            Assert.That(attackedWarrior.HP, Is.EqualTo(100));
        }

        [Test]
        public void CheckAfterAttackEnemysDies()
        {
            warrior = new Warrior("Pesho", 120, 400);
            Warrior attackedWarrior = new Warrior("Gosho", 20, 100);

            warrior.Attack(attackedWarrior);

            Assert.That(attackedWarrior.HP, Is.EqualTo(0));
            Assert.That(warrior.HP, Is.EqualTo(380));
        }







        //    [Test]
        //    public void CheckAfterAttackEnemysDiesWhenAttackAndHpArEqual()
        //    {
        //        warrior = new Warrior("Pesho", 100, 400);
        //        Warrior attackedWarrior = new Warrior("Gosho", 20, 100);

        //        warrior.Attack(attackedWarrior);

        //        Assert.That(attackedWarrior.HP, Is.EqualTo(0));
        //    }




        //    [Test]
        //    public void ConfirmNameGetterWorks()
        //    {
        //        string expected = "Pesho";
        //        string actual = warrior.Name;

        //        Assert.AreEqual(expected, actual);
        //    }







        //    [Test]
        //    public void ConfirmDamageGetterWorksProperly()
        //    {
        //        int expected = 20;
        //        int actual = warrior.Damage;

        //        Assert.AreEqual(expected, actual);
        //    }





        //    [Test]
        //    public void ConfirmHealthGetterWorksProperly()
        //    {
        //        int expected = 100;
        //        int actual = warrior.HP;

        //        Assert.AreEqual(expected, actual);
        //    }





        //    [Test]
        //    public void CheckAttackWithZaroHps()
        //    {
        //        warrior = new Warrior("Pesho", 10, 0);
        //        Warrior attackedWarrior = new Warrior("Gosho", 50, 50);

        //        Assert.Throws<InvalidOperationException>(() => warrior.Attack(attackedWarrior));
        //    }

        //    [Test]
        //    public void CheckAttackWithEqualToMinimumPoints()
        //    {
        //        warrior = new Warrior("Pesho", 10, 30);
        //        Warrior attackedWarrior = new Warrior("Gosho", 20, 30);

        //        Assert.Throws<InvalidOperationException>(() => warrior.Attack(attackedWarrior));
        //    }

        //    [Test]
        //    public void CheckAttackWithEqualToMinimumPointsAndDefenderLess()
        //    {
        //        warrior = new Warrior("Pesho", 10, 30);
        //        Warrior attackedWarrior = new Warrior("Gosho", 20, 20);

        //        Assert.Throws<InvalidOperationException>(() => warrior.Attack(attackedWarrior));
        //    }



        //    [Test]
        //    public void CheckAttackSomebodyWithLessThanMinimumPoints()
        //    {
        //        warrior = new Warrior("Pesho", 10, 300);
        //        Warrior attackedWarrior = new Warrior("Gosho", 50, 20);

        //        Assert.Throws<InvalidOperationException>(() => warrior.Attack(attackedWarrior));
        //    }



        //    [Test]
        //    public void AttackSomebodyWithMoreHpThanCurrentHP()
        //    {
        //        warrior = new Warrior("Pesho", 10, 40);
        //        Warrior attackedWarrior = new Warrior("Gosho", 50, 200);

        //        Assert.Throws<InvalidOperationException>(() => warrior.Attack(attackedWarrior));
        //    }



        //    [Test]
        //    public void CheckAfterAttackEnemysLoosesHp()
        //    {
        //        warrior = new Warrior("Pesho", 100, 400);
        //        Warrior attackedWarrior = new Warrior("Gosho", 20, 200);

        //        warrior.Attack(attackedWarrior);

        //        Assert.That(attackedWarrior.HP, Is.EqualTo(100));
        //    }



        //}


      
    }
}