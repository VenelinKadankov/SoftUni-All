//using CarManagerProblem;
using NUnit.Framework;
using System;

namespace Tests
{
    public class CarTests
    {

        private Car testCar;

        [SetUp]
        public void Setup()
        {
            testCar = new Car("Ford", "Ka", 5, 50);
        }

        [Test]
        public void ConfirmConstructorCreatesRealObject()
        {
            Assert.IsNotNull(testCar);
        }

        [Test]
        public void ConfirmNullForMakeThrowsException()
        {
            Assert.That(() => testCar = new Car(null, "Ka", 1, 4),
                Throws.ArgumentException.With.Message.EqualTo("Make cannot be null or empty!"));
        }

        [Test]
        public void ConfirmNullForModelThrowsException()
        {
            Assert.That(() => testCar = new Car("Ford", null, 1, 4),
                Throws.ArgumentException.With.Message.EqualTo("Model cannot be null or empty!"));
        }

        [Test]
        public void ConfirmNegativeForFuelConsumptionThrowsException()
        {
            Assert.That(() => testCar = new Car("Ford", "Ka", -4, 4),
                Throws.ArgumentException.With.Message.EqualTo("Fuel consumption cannot be zero or negative!"));
        }

        [Test]
        public void ConfirmZeroForFuelCapacityThrowsException()
        {
            Assert.That(() => testCar = new Car("Ford", "Ka", 1, 0),
                Throws.ArgumentException.With.Message.EqualTo("Fuel capacity cannot be zero or negative!"));
        }

        [Test]
        public void ConfirmFuelAmountGetterReturnsCorrectInformation()
        {
            double expected = 0;
            double actual = testCar.FuelAmount;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ConfirmRefuelIncreasesFuelAmount()
        {
            double expected = 15;
            testCar.Refuel(15);
            double actual = testCar.FuelAmount;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ConfirmRefuelWithNegativeamountThrowsException()
        {
            double testRefuel = -2;

            Assert.That(() => testCar.Refuel(testRefuel),
                Throws.ArgumentException.With.Message.EqualTo("Fuel amount cannot be zero or negative!"));
        }

        [Test]
        public void ConfirmPossibleToRefuelOnlyUpToFuelCapacity()
        {
            double expected = 50.0;
            testCar.Refuel(70);

            Assert.AreEqual(expected, testCar.FuelAmount);
        }

        [Test]
        public void ConfirmTravelingDecreasesFuelAmount()
        {
            testCar.Refuel(20);
            testCar.Drive(10);
            double expected = 19.5;
            double actual = testCar.FuelAmount;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ConfirmFuelIsZeroInEmptyConstructor()
        {
            Assert.That(testCar.FuelAmount == 0);
        }

        [Test]
        public void ConfirmMakeIsCorrect()
        {
            Assert.That(testCar.Make, Is.EqualTo("Ford"));
        }

        [Test]
        public void ConfirmModelIsCorrect()
        {
            Assert.That(testCar.Model, Is.EqualTo("Ka"));
        }

        [Test]
        public void ConfirmFuelConsumptionIsCorrect()
        {
            Assert.That(testCar.FuelConsumption, Is.EqualTo(5));
        }

        [Test]
        public void ConfirmFuelCapacityIsCorrect()
        {
            Assert.That(testCar.FuelCapacity, Is.EqualTo(50.0));
        }

        [Test]
        public void ConfirmZeroForFuelConsumptionThrowsException()
        {
            Assert.That(() => testCar = new Car("Ford", "Ka", 0, 4),
                Throws.ArgumentException.With.Message.EqualTo("Fuel consumption cannot be zero or negative!"));
        }

        [Test]
        public void ConfirmNegativeForFuelCapacityThrowsException()
        {
            Assert.That(() => testCar = new Car("Ford", "Ka", 1, -3),
                Throws.ArgumentException.With.Message.EqualTo("Fuel capacity cannot be zero or negative!"));
        }

        [Test]
        public void ConfirmMakeGetterReturnsCorrectInformation()
        {
            string expected = "Ford";
            string actual = testCar.Make;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ConfirmModelGetterReturnsCorrectInformation()
        {
            string expected = "Ka";
            string actual = testCar.Model;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ConfirmFuelConsumptionGetterReturnsCorrectInformation()
        {
            double expected = 5;
            double actual = testCar.FuelConsumption;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ConfirmFuelCapacityGetterReturnsCorrectInformation()
        {
            double expected = 50.0;
            double actual = testCar.FuelCapacity;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ConfirmSpendingMoreFuelThaAvailableThrowsException()
        {
            double testKm = 60;

            Assert.That(() => testCar.Drive(testKm),
                Throws.InvalidOperationException.With.Message.EqualTo("You don't have enough fuel to drive!"));
        }

        [Test]
        public void ConfirmRefuelWithZeroThrowsEsception()
        {

            Assert.Throws<ArgumentException>(() =>
            {
                this.testCar.Refuel(0);
            });

        }

    }
}
