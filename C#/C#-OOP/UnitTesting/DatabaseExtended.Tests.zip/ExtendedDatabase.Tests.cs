//using ExtendedDatabaseProblem;
using NUnit.Framework;
using System;

namespace Tests
{
    [TestFixture]
    public class ExtendedDatabaseTests
    {
        private ExtendedDatabase database;
        private ExtendedDatabase fullDatabase;
        private Person pesho;


        [SetUp]
        public void Setup()
        {
            pesho = new Person(123L, "Pesho");
            Person[] people = new Person[] { pesho };
            database = new ExtendedDatabase(people);

            Person[] people2 = new Person[16];
            people2[0] = new Person(123L, "Pesho");
            people2[1] = new Person(1L, "o");
            people2[2] = new Person(11L, "ow");
            people2[3] = new Person(111L, "oww");
            people2[4] = new Person(1111L, "owww");
            people2[5] = new Person(11111L, "owwww");
            people2[6] = new Person(12L, "oe");
            people2[7] = new Person(122L, "oee");
            people2[8] = new Person(1222L, "oeee");
            people2[9] = new Person(12222L, "oeeee");
            people2[10] = new Person(13L, "or");
            people2[11] = new Person(133L, "orr");
            people2[12] = new Person(1333L, "orrr");
            people2[13] = new Person(13333L, "orrrr");
            people2[14] = new Person(14L, "ot");
            people2[15] = new Person(144L, "ott");

            fullDatabase = new ExtendedDatabase(people2);
        }

        [Test]
        public void InitializeDatabaseWithEmptyConstructor()
        {
            Assert.DoesNotThrow(() => this.database = new ExtendedDatabase());
        }

        [Test]
        public void CheckIfDatabaseContainsWxpectedData()
        {
            Person pesho = new Person(1L, "Pesho");
            Person gosho = new Person(2L, "Gosho");

            Person[] expected = new Person[] { pesho, gosho };

            ExtendedDatabase db = new ExtendedDatabase(expected);


            Person[] actual = new Person[2];//expected;
            actual[0] = db.FindById(1L);
            actual[1] = db.FindById(2L);

            Assert.That(actual, Is.EqualTo(expected));

        }

        [Test]
        public void CheckThatConstructorThrowsMistakeIfArgumentHasLEngthMoreThanRequired()
        {
            Person[] people2 = new Person[17];
            people2[0] = new Person(123L, "Pesho");
            people2[1] = new Person(1L, "o");
            people2[2] = new Person(11L, "ow");
            people2[3] = new Person(111L, "oww");
            people2[4] = new Person(1111L, "owww");
            people2[5] = new Person(11111L, "owwww");
            people2[6] = new Person(12L, "oe");
            people2[7] = new Person(122L, "oee");
            people2[8] = new Person(1222L, "oeee");
            people2[9] = new Person(12222L, "oeeee");
            people2[10] = new Person(13L, "or");
            people2[11] = new Person(133L, "orr");
            people2[12] = new Person(1333L, "orrr");
            people2[13] = new Person(13333L, "orrrr");
            people2[14] = new Person(14L, "ot");
            people2[15] = new Person(144L, "ott");
            people2[16] = new Person(2L, "p");

            Assert.That(() => fullDatabase = new ExtendedDatabase(people2),
                Throws.ArgumentException);
        }

        [Test]
        public void CheckConstructorCapacityAfterInitiation()
        {
            Assert.That(fullDatabase.Count, Is.EqualTo(16));
        }


        [Test]
        public void InitializeDatabaseConstructorWithParameter()
        {
            Assert.That(this.database.Count, Is.EqualTo(1));
        }


        [Test]
        public void CheckIfAddingPersonWithSameNameIsPossible()
        {
            Person testPerson = new Person(333L, "Pesho");
            Assert.That(() => database.Add(testPerson),
                Throws.InvalidOperationException.With.Message.EqualTo("There is already user with this username!"));
        }

        [Test]
        public void CheckIfAddingPersonWithSameIdIsPossible()
        {
            Person testPerson = new Person(123L, "Gosho");
            Assert.That(() => database.Add(testPerson),
                Throws.InvalidOperationException.With.Message.EqualTo("There is already user with this Id!"));
        }

        [Test]

        public void AddPersonWithNullNameSholdNotBePossible()
        {
            Person person = new Person(33L, null);


            Assert.That(() => database.Add(person),
                Throws.InvalidOperationException);
        }

        [Test]
        public void CheckIfAddingPersonToFullDatabaseIsPossible()
        {

            database.Add(new Person(1L, "o"));
            database.Add(new Person(11L, "ow"));
            database.Add(new Person(111L, "oww"));
            database.Add(new Person(1111L, "owww"));
            database.Add(new Person(11111L, "owwww"));
            database.Add(new Person(12L, "oe"));
            database.Add(new Person(122L, "oee"));
            database.Add(new Person(1222L, "oeee"));
            database.Add(new Person(12222L, "oeeee"));
            database.Add(new Person(13L, "or"));
            database.Add(new Person(133L, "orr"));
            database.Add(new Person(1333L, "orrr"));
            database.Add(new Person(13333L, "orrrr"));
            database.Add(new Person(14L, "ot"));
            database.Add(new Person(144L, "ott"));

            //Person[] people = new Person[16];
            //database = new ExtendedDatabase(people);


            Person testPerson = new Person(12L, "Gosh");
            Assert.That(() => database.Add(testPerson),
                Throws.InvalidOperationException.With.Message.EqualTo("Array's capacity must be exactly 16 integers!"));
        }

        [Test]
        public void CheckIfAddingPersonToDatabaseIsWorking()
        {
            int oldCount = database.Count;
            Person testPerson = new Person(12L, "Ivan");
            database.Add(testPerson);
            int expected = database.Count;
            Assert.That(expected, Is.EqualTo(oldCount + 1));
        }

        [Test]
        public void RemovingFromEmptyDatabaseShouldBeImpossible()
        {
            database = new ExtendedDatabase();

            Assert.That(() => database.Remove(),
                Throws.InvalidOperationException);
        }

        [Test]
        public void CheckRemovingFromDatabase()
        {
            int oldCount = database.Count;
            database.Remove();
            int expected = database.Count;
            Assert.That(expected, Is.EqualTo(oldCount - 1));
        }

        [Test]
        public void CheckIfRemoveMethodRemovesLastElement()
        {
            long lastId = 144L;

            fullDatabase.Remove();

            Assert.That(() => fullDatabase.FindById(lastId),
                Throws.InvalidOperationException);
        }

        [Test]
        public void CheckIfFindByInvalidUsernameFails()
        {
            string name = "Prokopi";

            Assert.That(() => database.FindByUsername(name),
                Throws.InvalidOperationException.With.Message.EqualTo("No user is present by this username!"));
        }

        [Test]
        public void CheckIfFindByEmptyUsernameFails()
        {
            string name = null;

            Assert.That(() => database.FindByUsername(name),
                Throws.ArgumentNullException);  // Throws.ArgumentNullException.With.Message.EqualTo("Username parameter is null!")
        }

        [Test]
        public void CheckIfFindingCaseInsensitiveNameWokrs()
        {
            string name = "peShO";

            Assert.That(() => database.FindByUsername(name),
                Throws.InvalidOperationException.With.Message.EqualTo("No user is present by this username!"));
        }

        [Test]
        public void CheckIfFindValidUsernameWorks()
        {

            Assert.That(() => database.FindByUsername("Pesho"), Is.EqualTo(pesho));
        }

        [Test]
        public void CheckIfFindByInvalidIdFails()
        {
            long testId = 666L;

            Assert.That(() => database.FindById(testId),
                Throws.InvalidOperationException.With.Message.EqualTo("No user is present by this ID!"));
        }

        [Test]
        public void CheckIfFindByNegativeIdFails()
        {
            long testId = -6L;
            var ex = Assert.Throws<ArgumentOutOfRangeException>(() => database.FindById(testId));

            Assert.That(ex.Message.Contains("Id should be a positive number!"));//, Is.EqualTo("Id should be a positive number!"));
        }

        [Test]
        public void CheckIfFindByIdFindsTheWantedPerson()
        {
            long testId = 123L;
            var testFindPerson = database.FindById(testId);

            Assert.That(testFindPerson.UserName, Is.EqualTo("Pesho"));
        }

        [Test]
        public void CheckIfAddingMoreThanLimitInConstructorIsPossible()
        {
            Person[] testArr = new Person[20];

            Assert.That(() => database = new ExtendedDatabase(testArr),
                Throws.ArgumentException.With.Message.EqualTo("Provided data length should be in range [0..16]!"));
        }
    }
}