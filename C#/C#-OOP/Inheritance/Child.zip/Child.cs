﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Person
{
    public class Child : Person
    {
        public Child(string name, int age)
            : base(name, age)
        {

        }

        public uint age {
            get
            {
                return age;
            } 
            set
            {
                if (value <= 15)
                {
                    this.age = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Age can not be more than 15");
                }
            }
        }
    }
}
