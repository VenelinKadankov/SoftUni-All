﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            BladeKnight knight = new BladeKnight("Ivan", 21);

            System.Console.WriteLine(knight.ToString());
        }
    }
}