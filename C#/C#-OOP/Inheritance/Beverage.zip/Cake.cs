﻿namespace Restaurant
{
    public class Cake : Dessert
    {
        private const double grams = 250D;
        private const double calories = 1000D;
        private const decimal price = 5M;
        public Cake(string name)
            : base(name, price, grams, calories)
        {

        }

    }
}
