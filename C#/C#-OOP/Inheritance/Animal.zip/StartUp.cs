﻿using System;

namespace Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            while (true)
            {
                string type = Console.ReadLine();

                if (type == "Beast!")
                {
                    break;
                }

                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (tokens.Length != 3)
                {
                    Console.WriteLine("Invalid input!");
                    continue;
                }

                if (int.TryParse(tokens[1], out int age))
                {
                    if (age < 0)
                    {
                        Console.WriteLine("Invalid input!");
                        continue;
                    }

                    switch (type)
                    {
                        case "Dog":
                            Dog dog = new Dog(tokens[0], age, tokens[2]);
                            Console.WriteLine(dog.GetType().Name);
                            Console.WriteLine($"{dog.Name} {dog.Age} {dog.Gender}");
                            Console.WriteLine(dog.ProduceSound());
                            break;                       
                        case "Frog":
                            Frog frog = new Frog(tokens[0], age, tokens[2]);
                            Console.WriteLine(frog.GetType().Name);
                            Console.WriteLine($"{frog.Name} {frog.Age} {frog.Gender}");
                            Console.WriteLine(frog.ProduceSound());
                            break;                        
                        case "Cat":
                            Cat cat = new Cat(tokens[0], age, tokens[2]);
                            Console.WriteLine(cat.GetType().Name);
                            Console.WriteLine($"{cat.Name} {cat.Age} {cat.Gender}");
                            Console.WriteLine(cat.ProduceSound());
                            break;                        
                        case "Kitten":
                            Kitten kitten = new Kitten(tokens[0], age);
                            Console.WriteLine(kitten.GetType().Name);
                            Console.WriteLine($"{kitten.Name} {kitten.Age} {kitten.Gender}");
                            Console.WriteLine(kitten.ProduceSound());
                            break;
                        case "Tomcat":
                            Tomcat tomcat = new Tomcat(tokens[0], age);
                            Console.WriteLine(tomcat.GetType().Name);
                            Console.WriteLine($"{tomcat.Name} {tomcat.Age} {tomcat.Gender}");
                            Console.WriteLine(tomcat.ProduceSound());
                            break;
                        default:
                            break;
                    }

                }
                else
                {
                    Console.WriteLine("Invalid input!");
                    continue;
                }

            }
        }
    }
}
