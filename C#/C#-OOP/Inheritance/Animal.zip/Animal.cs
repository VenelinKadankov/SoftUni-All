﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals
{
    public class Animal
    {
        public Animal(string name, int age, string gender)
        {
            this.Name = name;
            this.Age = age;
            this.Gender = gender;
        }

        public string Name { get; set; }
        public int Age { get; set; }
        //{
        //    get
        //    {
        //        return this.Age;
        //    }
        //    set
        //    {
        //        if (value > 0)
        //        {
        //            this.Age = value;
        //        }
        //        else
        //        {
        //            throw new ArgumentOutOfRangeException("Invalid operation!");
        //        }
        //    }
        //}
        public string Gender { get; set; }
        //{
        //    get
        //    {
        //        return this.Gender;
        //    }
        //    set
        //    {
        //        if (value == "Male" || value == "Female")
        //        {
        //            this.Gender = value;
        //        }
        //        else
        //        {
        //            throw new ArgumentOutOfRangeException("Invalid operation!");
        //        }
        //    }
        //}



        public virtual string ProduceSound()
        {
            return $"";
        }
    }
}
