﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using SoftUni.Data;
using SoftUni.Models;
using System;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var db = new SoftUniContext();

            // var result3 = GetEmployeesFullInformation(db);
            //var result4 = GetEmployeesWithSalaryOver50000(db);
            //var result5 = GetEmployeesFromResearchAndDevelopment(db);
            //var result6 = AddNewAddressToEmployee(db);
            //var result7 = GetEmployeesInPeriod(db);
            //var result8 = GetAddressesByTown(db);
            //var result9 = GetEmployee147(db);
            var result = GetDepartmentsWithMoreThan5Employees(db);

            Console.WriteLine(result);
        }

        public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
        {
            var depts = context.Departments
                .Include(x => x.Employees)
                .Where(x => x.Employees.Count > 5)
                .Select(x => new
                {
                    ManagerFirstName = x.Manager.FirstName,
                    ManagerSecondName = x.Manager.LastName,
                    x.Name,
                    Employees = x.Employees.Select(y => new
                    {
                        y.FirstName,
                        y.LastName,
                        y.JobTitle
                    })
                    //.OrderBy(a => a.FirstName)
                   // .ThenBy(a => a.LastName)
                })
                .ToList();

            var sb = new StringBuilder();

            foreach (var item in depts)
            {
                sb.AppendLine($"{item.Name} - {item.ManagerFirstName} {item.ManagerSecondName}");

                foreach (var emp in item.Employees.OrderBy(a => a.FirstName).ThenBy(a => a.LastName))
                {
                    sb.AppendLine($"{emp.FirstName} {emp.LastName} - {emp.JobTitle}");
                }
            }

            return sb.ToString();
        }

        public static string GetEmployee147(SoftUniContext context)
        {
    //        var emp147 = context.Employees
                 //.Include(x => x.EmployeesProjects)
                 //.ThenInclude(x => x.Project)
                 //.Where(x => x.EmployeeId == 147)
                 //.FirstOrDefault();

    //        StringBuilder sb = new StringBuilder();
    //        sb.AppendLine($"{emp147.FirstName} {emp147.LastName} - {emp147.JobTitle}");

    //        var projects = emp147.EmployeesProjects.OrderBy(x => x.Project.Name);

    //        foreach (var proj in projects)
    //        {
    //            sb.AppendLine($"{proj.Project.Name}");
    //        }

    //        var result = sb.ToString().TrimEnd();

    //        return result;

            var emp147 = context.Employees
                .Select(x => new Employee
                {
                    EmployeeId = x.EmployeeId,
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                    JobTitle = x.JobTitle,
                    EmployeesProjects = x.EmployeesProjects.Select(a => new EmployeeProject
                    {
                        Project = a.Project
                    })
                    .OrderBy(x => x.Project.Name)
                    .ToList()
                })
                .FirstOrDefault(x => x.EmployeeId == 147);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"{emp147.FirstName} {emp147.LastName} - {emp147.JobTitle}");

            foreach (var proj in emp147.EmployeesProjects)
            {
                sb.AppendLine($"{proj.Project.Name}");
            }


            var result = sb.ToString().TrimEnd();

            return result;
        }

        public static string GetAddressesByTown(SoftUniContext context)
        {
            var emps = context
                .Addresses
                .Include(x => x.Town)
                .Include(x => x.Employees)
                .OrderByDescending(x => x.Employees.Count)
                .ThenBy(x => x.Town.Name)
                .ThenBy(x => x.AddressText)
                .Take(10)
                .ToList();



            StringBuilder sb = new StringBuilder();

            foreach (var item in emps)
            {
                sb.AppendLine($"{item.AddressText}, { item.Town.Name} - {item.Employees.Count} employees");
            }

            var result = sb.ToString().TrimEnd();

            return result;
        }

        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            var emps = context.Employees
                .Include(x => x.EmployeesProjects)
                .ThenInclude(x => x.Project)
                .Where(x => x.EmployeesProjects.Any(y => y.Project.StartDate.Year >= 2001 && y.Project.StartDate.Year <= 2003))
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    ManagerFirstName = x.Manager.FirstName,
                    ManagerLastName = x.Manager.LastName,
                    Projects = x.EmployeesProjects.Select(p => new
                    {
                        ProjectName = p.Project.Name,
                        ProjectStart = p.Project.StartDate,
                        ProjectEnd = p.Project.EndDate
                    })
                })
                .Take(10)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var item in emps)
            {
                sb.AppendLine($"{item.FirstName} {item.LastName} - Manager: {item.ManagerFirstName} {item.ManagerLastName}");

                foreach (var eP in item.Projects)
                {
                    var endDate = eP.ProjectEnd.HasValue
                        ? eP.ProjectEnd.Value.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture)
                        : "not finished";

                    sb.AppendLine($"--{eP.ProjectName} - {eP.ProjectStart} - {endDate}");

                }
            }

            return sb.ToString();
        }

        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            var nakov = context.Employees
                .Where(x => x.LastName == "Nakov")
                .FirstOrDefault();

            var address = new Address
            {
                TownId = 4,
                AddressText = "Vitoshka 15"
            };

            context.Addresses.Add(address);
            context.SaveChanges();

            //nakov.Address.TownId = 4;
            //nakov.Address.AddressText = "Vitoshka 15";

            nakov.AddressId = address.AddressId;

            context.SaveChanges();

            var emps = context.Employees
                .OrderByDescending(x => x.AddressId)
                .Select(x => new
                { 
                    EmployeeAddressText = x.Address.AddressText
                })
                .Take(10)
                .ToList();

            StringBuilder sb = new StringBuilder();

            foreach (var item in emps)
            {
                sb.AppendLine(item.EmployeeAddressText);
            }

            var result = sb.ToString().TrimEnd();

            return result;
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var emps = context.Employees
                .Where(x => x.Department.Name == "Research and Development")
                .Select(x => new
                {
                    x.FirstName,
                    x.LastName,
                    x.Department.Name,
                    x.Salary,
                })
                .OrderBy(x => x.Salary)
                .ThenByDescending(x => x.FirstName)
                .ToList();

            foreach (var item in emps)
            {
                sb.AppendLine($"{item.FirstName} {item.LastName} from {item.Name} - ${item.Salary:F2}");
            }

            var result = sb.ToString().TrimEnd();

            return result;
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var emps = context.Employees
                .Select(x => new
                {
                    x.FirstName,
                    x.Salary
                })
                .Where(x => x.Salary > 50000)
                .OrderBy(x => x.FirstName)
                .ToList();

            foreach (var item in emps)
            {
                sb.AppendLine($"{item.FirstName} - {item.Salary:f2}");
            }

            var result = sb.ToString().Trim();

            return result;
        }

        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employeesData = context.Employees
                .Select(x => new
                {
                    x.EmployeeId,
                    x.FirstName,
                    x.LastName,
                    x.MiddleName,
                    x.JobTitle,
                    x.Salary
                })
                .OrderBy(e => e.EmployeeId)
                .ToList();
            StringBuilder sb = new StringBuilder();

            foreach (var item in employeesData)
            {
                //sb.Append($"{item.FirstName} {item.LastName} ");

                //if (item.MiddleName != null)
                //{
                //    sb.Append($"{item.MiddleName} ");
                //}

                //sb.AppendLine($"{item.Department} {item.JobTitle} {item.Salary:f2}");

                sb.AppendLine($"{item.FirstName} {item.LastName} {item.MiddleName} {item.JobTitle} {item.Salary:f2}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
